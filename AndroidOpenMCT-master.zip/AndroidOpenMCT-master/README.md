AndroidOpenMCT
==============

A app for multiple choice tests on Android devices.

You can find an article about it here:
http://cacodaemon.de/index.php?id=46
